import React, { useState, useEffect } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import './Calendario.css';
import { useParams, useNavigate } from 'react-router-dom';

const Calendario = () => {
  const [eventos, setEventos] = useState([]);
  const { projectId } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (!projectId) return;

    const token = localStorage.getItem('token');

    fetch(`https://localhost:7286/api/tasks?projectId=${projectId}`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
      .then((res) => {
        if (res.status === 403) {
          alert('No tienes acceso a este proyecto');
          navigate('/home');
          return;
        }
        if (!res.ok) throw new Error('Failed to fetch tasks');
        return res.json();
      })
      .then((data) => {
        if (data) {
          const eventosFormateados = data.map((task) => ({
            id: task.id,
            title: task.title,
            start: task.start,
            end: task.deadline,
            backgroundColor: getColor(task.status),
          }));
          setEventos(eventosFormateados);
        }
      })
      .catch((err) => console.error('Error cargando tareas:', err));
  }, [projectId, navigate]);

  const getColor = (status) => {
    if (status === 'active') return '#3498db';
    if (status === 'inactive') return '#95a5a6';
    return '#2ecc71';
  };

  return (
    <div className="calendario-container">
      <div className="calendario-content" style={{ height: 'calc(100vh - 80px)' }}>
        <div className="calendario-header">
          <h1>Calendario</h1>
        </div>

        <div className="calendario-main" style={{ height: '100%' }}>
          <FullCalendar
            plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
            initialView="dayGridMonth"
            headerToolbar={{
              left: 'prev,next today',
              center: 'title',
              right: 'dayGridMonth,timeGridWeek',
            }}
            events={eventos}
            locale="es"
            height="100%"
          />
        </div>
      </div>
    </div>
  );
};

export default Calendario;