import React, { useState } from 'react';

export function CreateTaskButton({ projectId, onTaskCreated }) {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    Title: '',
    Description: '',
    Priority: 'Medium',
    Type: 'Task',
    DependsOn: []
  });
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const token = localStorage.getItem('token');
    try {
      const response = await fetch('https://localhost:7286/api/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
            ProjectId: projectId,
            Title: formData.Title,
            Description: formData.Description,
            Priority: formData.Priority,
            Type: formData.Type,
            DependsOn: formData.DependsOn
            
            })

      });

      if (response.ok) {
        setFormData({
          Title: '',
          Description: '',
          Priority: 'Medium',
          Type: 'Task',
          DependsOn: []
        });
        setShowForm(false);
        if (onTaskCreated) onTaskCreated();
      } else {
        setError('Error al crear la tarea');
      }
    } catch (err) {
      console.error('Error creating task:', err);
      setError('Error al crear la tarea');
    }
  };

  return (
    <div>
      <button
        onClick={() => setShowForm(!showForm)}
        style={{
          padding: '10px 20px',
          backgroundColor: '#2ecc71',
          color: '#fff',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer',
          marginBottom: '10px'
        }}>
        {showForm ? 'Cancelar' : '+ Crear Tarea'}
      </button>

      {showForm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000
        }}>
          <div style={{
            background: '#fff',
            padding: '30px',
            borderRadius: '8px',
            width: '500px',
            maxWidth: '90%',
            maxHeight: '90vh',
            overflowY: 'auto'
          }}>
            <h2>Crear Nueva Tarea</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '15px' }}>
                <label>Título</label>
                <input
                  type="text"
                  value={formData.Title}
                  onChange={(e) => setFormData({...formData, Title: e.target.value})}
                  required
                  style={{
                    width: '100%',
                    padding: '8px',
                    marginTop: '5px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label>Descripción</label>
                <textarea
                  value={formData.Description}
                  onChange={(e) => setFormData({...formData, Description: e.target.value})}
                  required
                  style={{
                    width: '100%',
                    padding: '8px',
                    marginTop: '5px',
                    borderRadius: '4px',
                    border: '1px solid #ccc',
                    minHeight: '80px'
                  }}
                />
              </div>

              <div style={{ marginBottom: '15px' }}>
                <label>Prioridad</label>
                <select
                  value={formData.Priority}
                  onChange={(e) => setFormData({...formData, Priority: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    marginTop: '5px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}>
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                </select>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label>Tipo</label>
                <select
                  value={formData.Type}
                  onChange={(e) => setFormData({...formData, Type: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    marginTop: '5px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}>
                  <option value="Task">Task</option>
                  <option value="Bug">Bug</option>
                  <option value="Feature">Feature</option>
                </select>
              </div>

              <div style={{ display: 'flex', gap: '10px' }}>
                <button type="submit" style={{
                  flex: 1,
                  padding: '10px',
                  backgroundColor: '#2ecc71',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}>
                  Crear
                </button>
                <button type="button" onClick={() => setShowForm(false)} style={{
                  flex: 1,
                  padding: '10px',
                  backgroundColor: '#95a5a6',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}>
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}